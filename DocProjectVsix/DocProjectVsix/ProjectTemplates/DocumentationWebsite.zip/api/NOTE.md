﻿*NOTE*:
This folder and its folder name is **Preserved** for API generation.

Please don't use it.
You can reference to the API documentation by adding href **api** to your toc.yaml